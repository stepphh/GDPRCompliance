package com.stepphh.gdprcompliance;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    String company = "My Company";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void Email(View view) {
        String EmailSubject = "[REQUEST GDPR Compliancy Evaluation] for " + company;
        String EmailBody = "";
        Log.i("Email: ", "Email() has been called");
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setType("text/html");
        intent.setData(Uri.parse("mailto: gdprforce@businessname.com"));
        intent.putExtra(Intent.EXTRA_EMAIL, "emailaddress@emailaddress.com");
        intent.putExtra(Intent.EXTRA_SUBJECT, EmailSubject);
        intent.putExtra(Intent.EXTRA_TEXT, EmailBody);

        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);

        }
    }



}
